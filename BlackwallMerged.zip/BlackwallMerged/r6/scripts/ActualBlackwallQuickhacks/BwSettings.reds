// Blackwall Quickhacks - Mod Settings menusu
// Bu dosyada bilerek "module" satiri yok: CET (Lua) tarafi BwBridge sinifini
// duz ismiyle cagirabilsin diye global isim alaninda tutuluyor.

public enum BwSpreadMode {
  Off = 0,
  OneByOne = 1,
  Burst = 2
}

public enum BwSpreadResource {
  RAM = 0,
  Health = 1
}

public class BwConfig {

  // ---------------------------------------------------------------- Genel
  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Genel")
  @runtimeProperty("ModSettings.category.order", "0")
  @runtimeProperty("ModSettings.order", "0")
  @runtimeProperty("ModSettings.displayName", "Ekran Efektlerini Göster")
  @runtimeProperty("ModSettings.description", "Blackwall kullanılırken ekran efektini gösterir.")
  public let showEffects: Bool = true;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Genel")
  @runtimeProperty("ModSettings.category.order", "0")
  @runtimeProperty("ModSettings.order", "1")
  @runtimeProperty("ModSettings.displayName", "El Animasyonlarını Kullan")
  @runtimeProperty("ModSettings.description", "Hack sırasında el animasyonunu oynatır.")
  public let useAnimations: Bool = true;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Genel")
  @runtimeProperty("ModSettings.category.order", "0")
  @runtimeProperty("ModSettings.order", "2")
  @runtimeProperty("ModSettings.displayName", "Araç/Cihaz Hedeflemeyi Etkinleştir")
  @runtimeProperty("ModSettings.description", "Nişan aldığın araç/cihaza Blackwall uygular. CET Bindings sekmesinden 'Arac/Cihaz Blackwall' için bir tuş atamalısın.")
  public let vehicleEnabled: Bool = false;

  // ------------------------------------------------------ Menzil ve Süreler
  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Menzil ve Süreler")
  @runtimeProperty("ModSettings.category.order", "1")
  @runtimeProperty("ModSettings.order", "0")
  @runtimeProperty("ModSettings.displayName", "Çoklu Hedef Menzili")
  @runtimeProperty("ModSettings.description", "Çoklu hedef Blackwall'un etkileyeceği alan (metre).")
  @runtimeProperty("ModSettings.step", "5")
  @runtimeProperty("ModSettings.min", "1")
  @runtimeProperty("ModSettings.max", "500")
  public let multiRange: Int32 = 75;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Menzil ve Süreler")
  @runtimeProperty("ModSettings.category.order", "1")
  @runtimeProperty("ModSettings.order", "1")
  @runtimeProperty("ModSettings.displayName", "Yükleme Süresi (Tekli Hedef)")
  @runtimeProperty("ModSettings.description", "Hedefin başındaki yükleme çubuğunun dolma süresi (saniye).")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.001")
  @runtimeProperty("ModSettings.max", "10.0")
  public let uploadSingle: Float = 0.001;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Menzil ve Süreler")
  @runtimeProperty("ModSettings.category.order", "1")
  @runtimeProperty("ModSettings.order", "2")
  @runtimeProperty("ModSettings.displayName", "Yükleme Süresi (Çoklu Hedef)")
  @runtimeProperty("ModSettings.description", "Hedeflerin başındaki yükleme çubuğunun dolma süresi (saniye).")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.001")
  @runtimeProperty("ModSettings.max", "10.0")
  public let uploadMulti: Float = 0.001;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Menzil ve Süreler")
  @runtimeProperty("ModSettings.category.order", "1")
  @runtimeProperty("ModSettings.order", "3")
  @runtimeProperty("ModSettings.displayName", "Yeniden Kullanım Süresi (Cooldown)")
  @runtimeProperty("ModSettings.description", "Blackwall'dan sonra tekrar kullanabilmek için beklenecek süre (saniye).")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "0.0001")
  @runtimeProperty("ModSettings.max", "120.0")
  public let cooldown: Float = 0.0001;

  // ------------------------------------------------------------- Maliyet
  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "0")
  @runtimeProperty("ModSettings.displayName", "RAM Tüket (Tekli Hedef)")
  public let drainMemorySingle: Bool = false;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "1")
  @runtimeProperty("ModSettings.displayName", "Tüketilecek RAM (Tekli Hedef)")
  @runtimeProperty("ModSettings.dependency", "drainMemorySingle")
  @runtimeProperty("ModSettings.step", "1")
  @runtimeProperty("ModSettings.min", "1")
  @runtimeProperty("ModSettings.max", "30")
  public let memorySingle: Int32 = 1;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "2")
  @runtimeProperty("ModSettings.displayName", "RAM Tüket (Çoklu Hedef)")
  public let drainMemoryMulti: Bool = false;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "3")
  @runtimeProperty("ModSettings.displayName", "Tüketilecek RAM (Çoklu Hedef)")
  @runtimeProperty("ModSettings.dependency", "drainMemoryMulti")
  @runtimeProperty("ModSettings.step", "1")
  @runtimeProperty("ModSettings.min", "1")
  @runtimeProperty("ModSettings.max", "30")
  public let memoryMulti: Int32 = 1;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "4")
  @runtimeProperty("ModSettings.displayName", "Can Tüket (Tekli Hedef)")
  public let drainHealthSingle: Bool = false;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "5")
  @runtimeProperty("ModSettings.displayName", "Tüketilecek Can (Tekli Hedef)")
  @runtimeProperty("ModSettings.dependency", "drainHealthSingle")
  @runtimeProperty("ModSettings.step", "10.0")
  @runtimeProperty("ModSettings.min", "1.0")
  @runtimeProperty("ModSettings.max", "2000.0")
  public let healthSingle: Float = 1.0;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "6")
  @runtimeProperty("ModSettings.displayName", "Can Tüket (Çoklu Hedef)")
  public let drainHealthMulti: Bool = false;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Maliyet")
  @runtimeProperty("ModSettings.category.order", "2")
  @runtimeProperty("ModSettings.order", "7")
  @runtimeProperty("ModSettings.displayName", "Tüketilecek Can (Çoklu Hedef)")
  @runtimeProperty("ModSettings.dependency", "drainHealthMulti")
  @runtimeProperty("ModSettings.step", "10.0")
  @runtimeProperty("ModSettings.min", "1.0")
  @runtimeProperty("ModSettings.max", "2000.0")
  public let healthMulti: Float = 1.0;

  // --------------------------------------------------- Zincirleme Yayılma
  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Zincirleme Yayılma")
  @runtimeProperty("ModSettings.category.order", "3")
  @runtimeProperty("ModSettings.order", "0")
  @runtimeProperty("ModSettings.displayName", "Yayılma Modu")
  @runtimeProperty("ModSettings.description", "Kapalı: sadece ilk hedef. Teker Teker: hedef ölünce en yakın düşmana atlar. Çevreye Yayılma: menzildeki tüm düşmanlara aynı anda yayılır.")
  @runtimeProperty("ModSettings.displayValues.Off", "Kapalı")
  @runtimeProperty("ModSettings.displayValues.OneByOne", "Teker Teker")
  @runtimeProperty("ModSettings.displayValues.Burst", "Çevreye Yayılma")
  public let spreadMode: BwSpreadMode = BwSpreadMode.Off;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Zincirleme Yayılma")
  @runtimeProperty("ModSettings.category.order", "3")
  @runtimeProperty("ModSettings.order", "1")
  @runtimeProperty("ModSettings.displayName", "Yayılma Maliyeti Kaynağı")
  @runtimeProperty("ModSettings.displayValues.RAM", "RAM")
  @runtimeProperty("ModSettings.displayValues.Health", "Can")
  public let spreadResource: BwSpreadResource = BwSpreadResource.RAM;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Zincirleme Yayılma")
  @runtimeProperty("ModSettings.category.order", "3")
  @runtimeProperty("ModSettings.order", "2")
  @runtimeProperty("ModSettings.displayName", "Yayılma Başına Maliyet")
  @runtimeProperty("ModSettings.description", "Zincirdeki her yeni yayılma adımı için harcanacak RAM ya da Can.")
  @runtimeProperty("ModSettings.step", "0.5")
  @runtimeProperty("ModSettings.min", "0.1")
  @runtimeProperty("ModSettings.max", "100.0")
  public let spreadAmount: Float = 1.0;

  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Zincirleme Yayılma")
  @runtimeProperty("ModSettings.category.order", "3")
  @runtimeProperty("ModSettings.order", "3")
  @runtimeProperty("ModSettings.displayName", "Yayılma Menzili")
  @runtimeProperty("ModSettings.description", "Ölen hedefin etrafında yeni hedef aranacak yarıçap (metre).")
  @runtimeProperty("ModSettings.step", "1.0")
  @runtimeProperty("ModSettings.min", "1.0")
  @runtimeProperty("ModSettings.max", "100.0")
  public let spreadRange: Float = 20.0;

  // --------------------------------------------------------- Blackwall Ver
  // Mod Settings'te gercek bir dugme tipi yok. Bu anahtar dugme gibi calisir:
  // Acik yap -> Uygula -> quickhack envantere eklenir, anahtar kendini kapatir.
  @runtimeProperty("ModSettings.mod", "Blackwall Quickhacks")
  @runtimeProperty("ModSettings.category", "Blackwall Ver")
  @runtimeProperty("ModSettings.category.order", "4")
  @runtimeProperty("ModSettings.order", "0")
  @runtimeProperty("ModSettings.displayName", "Blackwall Quickhack'ini Karaktere Ver")
  @runtimeProperty("ModSettings.description", "Açık yapıp Uygula'ya bas: Blackwall quickhack programı envanterine eklenir. Sonra Cyberdeck'ine tak.")
  public let giveBlackwall: Bool = false;
}

// ------------------------------------------------------------------------
// Ayarlari tutan sistem. Oyun oturumu basladiginda otomatik olusur.
public class BwSystem extends ScriptableSystem {
  private let m_config: ref<BwConfig>;

  private func OnAttach() -> Void {
    this.m_config = new BwConfig();
    BwRegisterConfig(this.m_config);
  }

  private func OnDetach() -> Void {
    BwUnregisterConfig(this.m_config);
  }

  public func GetConfig() -> ref<BwConfig> {
    return this.m_config;
  }
}

// ------------------------------------------------------------------------
// CET (Lua) bu sinifin static fonksiyonlarini cagirip ayarlari okur.
public class BwBridge {

  public static func Sys() -> ref<BwSystem> {
    return GameInstance.GetScriptableSystemsContainer(GetGameInstance()).Get(n"BwSystem") as BwSystem;
  }

  public static func IsReady() -> Bool {
    let sys: ref<BwSystem> = BwBridge.Sys();
    if !IsDefined(sys) {
      return false;
    };
    return IsDefined(sys.GetConfig());
  }

  public static func GetBool(key: String) -> Bool {
    let sys: ref<BwSystem> = BwBridge.Sys();
    if !IsDefined(sys) {
      return false;
    };
    let c: ref<BwConfig> = sys.GetConfig();
    if !IsDefined(c) {
      return false;
    };
    if Equals(key, "showEffects") { return c.showEffects; };
    if Equals(key, "useAnimations") { return c.useAnimations; };
    if Equals(key, "vehicleEnabled") { return c.vehicleEnabled; };
    if Equals(key, "drainMemorySingle") { return c.drainMemorySingle; };
    if Equals(key, "drainMemoryMulti") { return c.drainMemoryMulti; };
    if Equals(key, "drainHealthSingle") { return c.drainHealthSingle; };
    if Equals(key, "drainHealthMulti") { return c.drainHealthMulti; };
    if Equals(key, "giveBlackwall") { return c.giveBlackwall; };
    return false;
  }

  public static func GetNumber(key: String) -> Float {
    let sys: ref<BwSystem> = BwBridge.Sys();
    if !IsDefined(sys) {
      return 0.0;
    };
    let c: ref<BwConfig> = sys.GetConfig();
    if !IsDefined(c) {
      return 0.0;
    };
    if Equals(key, "multiRange") { return Cast<Float>(c.multiRange); };
    if Equals(key, "uploadSingle") { return c.uploadSingle; };
    if Equals(key, "uploadMulti") { return c.uploadMulti; };
    if Equals(key, "cooldown") { return c.cooldown; };
    if Equals(key, "memorySingle") { return Cast<Float>(c.memorySingle); };
    if Equals(key, "memoryMulti") { return Cast<Float>(c.memoryMulti); };
    if Equals(key, "healthSingle") { return c.healthSingle; };
    if Equals(key, "healthMulti") { return c.healthMulti; };
    if Equals(key, "spreadAmount") { return c.spreadAmount; };
    if Equals(key, "spreadRange") { return c.spreadRange; };
    if Equals(key, "spreadMode") { return Cast<Float>(EnumInt(c.spreadMode)); };
    if Equals(key, "spreadResource") { return Cast<Float>(EnumInt(c.spreadResource)); };
    return 0.0;
  }

  // "Ver" anahtarini tekrar kapali konuma getirir.
  public static func ResetGive() -> Void {
    let sys: ref<BwSystem> = BwBridge.Sys();
    if !IsDefined(sys) {
      return;
    };
    let c: ref<BwConfig> = sys.GetConfig();
    if IsDefined(c) {
      BwResetSwitch(c);
    };
  }
}

// ------------------------------------------------------------------------
// Mod Settings kuruluysa kullan, kurulu degilse hicbir sey yapma (derleme bozulmaz).
@if(ModuleExists("ModSettingsModule"))
public func BwRegisterConfig(config: ref<BwConfig>) -> Void {
  ModSettings.RegisterListenerToClass(config);
}

@if(!ModuleExists("ModSettingsModule"))
public func BwRegisterConfig(config: ref<BwConfig>) -> Void {
}

@if(ModuleExists("ModSettingsModule"))
public func BwUnregisterConfig(config: ref<BwConfig>) -> Void {
  ModSettings.UnregisterListenerToClass(config);
}

@if(!ModuleExists("ModSettingsModule"))
public func BwUnregisterConfig(config: ref<BwConfig>) -> Void {
}

@if(ModuleExists("ModSettingsModule"))
public func BwResetSwitch(config: ref<BwConfig>) -> Void {
  let mod: CName = n"Blackwall Quickhacks";
  let categories: array<CName> = ModSettings.GetCategories(mod);
  let vars: array<ref<ConfigVar>>;
  let boolVar: ref<ModConfigVarBool>;
  let i: Int32 = 0;
  let j: Int32;
  config.giveBlackwall = false;
  while i < ArraySize(categories) {
    vars = ModSettings.GetVars(mod, categories[i]);
    j = 0;
    while j < ArraySize(vars) {
      boolVar = vars[j] as ModConfigVarBool;
      if IsDefined(boolVar) {
        if Equals(boolVar.GetName(), n"giveBlackwall") {
          boolVar.SetValue(false);
        };
      };
      j += 1;
    };
    i += 1;
  };
}

@if(!ModuleExists("ModSettingsModule"))
public func BwResetSwitch(config: ref<BwConfig>) -> Void {
  config.giveBlackwall = false;
}
