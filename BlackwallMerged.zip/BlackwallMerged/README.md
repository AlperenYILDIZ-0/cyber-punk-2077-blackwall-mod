# Actual Blackwall Quickhacks – Birleştirilmiş Sürüm (Mod Settings menülü)

Birleştirilen kaynaklar:
- Nexus "Actual Blackwall Quickhacks" (yaml kayıtları, .archive/.xl, Cron/Ref)
- GitHub "blackwall" sürümü (yükleme süresi, cooldown, can tüketimi, zincirleme yayılma, araç/cihaz hedefleme)
- Mod Settings menüsü + "Blackwall'u karaktere ver" düğmesi

## Gerekenler
RED4ext, redscript, TweakXL, ArchiveXL, Cyber Engine Tweaks, Mod Settings (v0.2.21; yüklediğin zip'teki `red4ext/plugins/mod_settings`).
REDmod kullanıyorsan cybercmd de gerekir.

## Kurulum
Bu klasörün içeriğini oyunun ana klasörüne kopyala (r6, bin, archive klasörleri birleşir).
Eski "Actual Blackwall Quickhacks" ve GitHub "blackwall" klasörlerini sil.
Eski `.../ActualBlackwallQuickhacks/settings.json` artık kullanılmaz.

## Kullanım
Ayarlar > Mod Settings > **Blackwall Quickhacks** (kategoriler: Genel, Menzil ve Süreler, Maliyet, Zincirleme Yayılma, Blackwall Ver).
Değişiklikleri **Uygula** ile onayla.

**Blackwall Ver:** "Blackwall Quickhack'ini Karaktere Ver" anahtarını aç > Uygula. Program envantere eklenir; Cyberdeck'e tak.
Yedek: CET overlay'indeki pencerede aynı işi yapan gerçek bir düğme var.

## Sorun giderme
- `r6/logs/redscript_rCURRENT.log` içinde derleme hatası var mı bak.
- CET konsolunda `TweakDB:GetRecord("Items.ActualBlackwallQuickhack")` nil ise TweakXL yaml'ı yüklenmemiştir.
